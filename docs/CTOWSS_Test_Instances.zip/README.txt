Nel file "benchmarks.txt" trovate, per ogni istanza, il benchmark da tenere in considerazione.

Al fine di poter accedere alla prova orale, � necessario che la media su tutte le istanze dell'errore commesso rispetto al benchmark dalla metaeuristica presentata sia inferiore al 5%.

N.B.: Il valore della distanza tra due nodi deve essere troncato alla terza cifra decimale (come avviene nel nuovo reader messo a disposizione).

